# NutriVision AI

NutriVision AI is a Generative AI Powered Smart Nutrition Analysis Platform. Snap a photo of your meal to instantly receive nutritional values, a real-time health score, and personalized suggestions from our Generative AI NutriBot.

## Features
- **AI Food Recognition**: Upload food images to automatically detect food items (powered by ultralytics YOLOv8).
- **Nutrition Calculation**: Get instant macro and micro-nutrient breakdown for your meal.
- **Generative AI Engine**: Receive a health score (0-100) and actionable insights on how to improve your diet (powered by transformers Text Generation).
- **NutriBot Assistant**: Chat directly with our built-in AI for personalized diet advice.
- **User Dashboard**: Track your average calorie intake, weight, and health scores over time with a modern, red-themed UI.

## Local Setup Instructions

1. **Clone the repository / navigate to project directory**:
   ```bash
   cd C:\Users\ragul\.gemini\antigravity\scratch\nutrivision_ai
   ```

2. **Activate the Virtual Environment**:
   *Windows (PowerShell)*:
   ```bash
   .\venv\Scripts\activate
   ```
   *Linux/Mac*:
   ```bash
   source venv/bin/activate
   ```

3. **Install Dependencies** (if not already installed):
   Ensure you run the initial installation command that installs required ML libraries:
   ```bash
   pip install Flask Flask-Login Flask-SQLAlchemy Flask-Bcrypt Pillow ultralytics transformers torch torchvision werkzeug python-dotenv
   ```

4. **Initialize Database & Run Application**:
   Simply run the application file. The database (`nutrivision.db`) will be automatically created on the first run.
   ```bash
   python run.py
   ```

5. **Access the Web App**:
   Open your browser and navigate to [http://127.0.0.1:5000](http://127.0.0.1:5000).

## Usage
- Click **Sign Up** to create an account.
- Navigate to **Scan Meal** on the dashboard.
- Upload any image (for demonstration, images containing simple foods like apple, banana, or pizza work best with the base YOLOv8 model).
- See the generated **Nutrition Results** and macro breakdowns.
- Go to the **NutriBot** page to ask questions like "How can I add more protein?"

> Note: The first time you upload an image or use the chatbot, the application might take a few moments to automatically download the required open-source AI models (`yolov8n.pt` and `HuggingFaceTB/SmolLM-135M`) to your local machine.

## Tech Stack
- **Backend Framework**: Python Flask
- **Frontend**: HTML5, Jinja2, TailwindCSS
- **Database**: SQLite (SQLAlchemy)
- **Computer Vision**: PyTorch, Ultralytics YOLOv8
- **Generative NLP Model**: Hugging Face Transformers
